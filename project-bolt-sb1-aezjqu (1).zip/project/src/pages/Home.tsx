import React from 'react';
import { PostCard } from '../components/feed/PostCard';
import { Pencil, Image, Video, Smile } from 'lucide-react';
import { Logo } from '../components/common/Logo';

const mockPosts = [
  {
    id: '1',
    userId: 'user1',
    content: 'Just launched our new social platform! 🚀',
    likes: 42,
    comments: 7,
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    userId: 'user2',
    content: 'Beautiful day for coding! ☀️',
    images: [
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
      'https://images.unsplash.com/photo-1461749280684-dccba630e2f6'
    ],
    likes: 24,
    comments: 3,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
];

export function Home() {
  return (
    <div className="max-w-2xl mx-auto py-6">
      <div className="text-center mb-8">
        <Logo className="inline-flex" />
        <p className="mt-2 text-gray-600">Connect with friends and share your moments</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
        <div className="flex items-center space-x-3">
          <img
            src="https://api.dicebear.com/7.x/avatars/svg?seed=current-user"
            alt="Your avatar"
            className="w-10 h-10 rounded-full"
          />
          <input
            type="text"
            placeholder="What's on your mind?"
            className="flex-1 bg-gray-100 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div className="mt-4 flex items-center justify-between pt-3 border-t">
          <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500">
            <Image className="h-5 w-5" />
            <span>Photo</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500">
            <Video className="h-5 w-5" />
            <span>Video</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500">
            <Smile className="h-5 w-5" />
            <span>Feeling</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500">
            <Pencil className="h-5 w-5" />
            <span>Write</span>
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {mockPosts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
}