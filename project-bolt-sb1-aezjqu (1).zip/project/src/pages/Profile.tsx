import React from 'react';
import { Settings, MapPin, Link as LinkIcon } from 'lucide-react';
import { PostCard } from '../components/feed/PostCard';

const mockUser = {
  name: 'John Doe',
  avatar: 'https://api.dicebear.com/7.x/avatars/svg?seed=john',
  bio: 'Software Developer | Coffee Enthusiast | Tech Blogger',
  location: 'San Francisco, CA',
  website: 'johndoe.dev',
  followers: 1234,
  following: 567,
};

const mockPosts = [
  {
    id: '1',
    userId: 'john',
    content: 'Working on some exciting new features! 💻',
    likes: 42,
    comments: 7,
    createdAt: new Date().toISOString(),
  },
];

export function Profile() {
  return (
    <div className="max-w-4xl mx-auto py-6">
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="h-48 bg-gradient-to-r from-blue-500 to-purple-500"></div>
        <div className="px-6 py-4 relative">
          <img
            src={mockUser.avatar}
            alt={mockUser.name}
            className="absolute -top-16 w-32 h-32 rounded-full border-4 border-white"
          />
          <div className="ml-36">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold">{mockUser.name}</h1>
              <button className="px-4 py-2 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Edit Profile</span>
              </button>
            </div>
            <p className="text-gray-600 mt-2">{mockUser.bio}</p>
            <div className="flex items-center space-x-4 mt-4 text-gray-600">
              <div className="flex items-center space-x-1">
                <MapPin className="h-4 w-4" />
                <span>{mockUser.location}</span>
              </div>
              <div className="flex items-center space-x-1">
                <LinkIcon className="h-4 w-4" />
                <a href={`https://${mockUser.website}`} className="text-blue-500 hover:underline">
                  {mockUser.website}
                </a>
              </div>
            </div>
            <div className="flex items-center space-x-6 mt-4">
              <div>
                <span className="font-bold">{mockUser.followers.toLocaleString()}</span>
                <span className="text-gray-500 ml-1">Followers</span>
              </div>
              <div>
                <span className="font-bold">{mockUser.following.toLocaleString()}</span>
                <span className="text-gray-500 ml-1">Following</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <div className="flex space-x-4 mb-4">
          <button className="px-4 py-2 font-semibold text-blue-500 border-b-2 border-blue-500">
            Posts
          </button>
          <button className="px-4 py-2 font-semibold text-gray-500 hover:text-blue-500">
            Media
          </button>
          <button className="px-4 py-2 font-semibold text-gray-500 hover:text-blue-500">
            Likes
          </button>
        </div>

        <div className="space-y-4">
          {mockPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </div>
  );
}