import React from 'react';
import { Heart, MessageCircle, UserPlus } from 'lucide-react';

const mockNotifications = [
  {
    id: '1',
    type: 'like',
    user: {
      name: 'Jane Smith',
      avatar: 'https://api.dicebear.com/7.x/avatars/svg?seed=jane'
    },
    content: 'liked your post',
    time: '2m ago'
  },
  {
    id: '2',
    type: 'comment',
    user: {
      name: 'Mike Johnson',
      avatar: 'https://api.dicebear.com/7.x/avatars/svg?seed=mike'
    },
    content: 'commented on your post: "Great work!"',
    time: '1h ago'
  },
  {
    id: '3',
    type: 'follow',
    user: {
      name: 'Sarah Wilson',
      avatar: 'https://api.dicebear.com/7.x/avatars/svg?seed=sarah'
    },
    content: 'started following you',
    time: '2h ago'
  }
];

const NotificationIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'like':
      return <Heart className="h-5 w-5 text-red-500" />;
    case 'comment':
      return <MessageCircle className="h-5 w-5 text-blue-500" />;
    case 'follow':
      return <UserPlus className="h-5 w-5 text-green-500" />;
    default:
      return null;
  }
};

export function Notifications() {
  return (
    <div className="max-w-2xl mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Notifications</h1>
      <div className="bg-white rounded-xl shadow-sm divide-y">
        {mockNotifications.map((notification) => (
          <div key={notification.id} className="p-4 hover:bg-gray-50 transition-colors">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <img
                  src={notification.user.avatar}
                  alt={notification.user.name}
                  className="w-12 h-12 rounded-full"
                />
                <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1">
                  <NotificationIcon type={notification.type} />
                </div>
              </div>
              <div className="flex-1">
                <p>
                  <span className="font-semibold">{notification.user.name}</span>
                  {' '}
                  {notification.content}
                </p>
                <span className="text-sm text-gray-500">{notification.time}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}