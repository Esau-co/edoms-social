import React from 'react';
import { Heart, MessageCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { Post } from '../../types';
import { ShareButton } from '../common/ShareButton';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  const postUrl = `${window.location.origin}/post/${post.id}`;

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
      <div className="flex items-start space-x-3">
        <img
          src={`https://api.dicebear.com/7.x/avatars/svg?seed=${post.userId}`}
          alt="avatar"
          className="w-10 h-10 rounded-full"
        />
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">User Name</h3>
            <span className="text-sm text-gray-500">
              {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
            </span>
          </div>
          <p className="mt-2 text-gray-800">{post.content}</p>
          {post.images && post.images.length > 0 && (
            <div className="mt-3 grid grid-cols-2 gap-2">
              {post.images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`Post image ${index + 1}`}
                  className="rounded-lg w-full h-48 object-cover"
                />
              ))}
            </div>
          )}
          <div className="mt-4 flex items-center space-x-4">
            <button className="flex items-center space-x-1 text-gray-500 hover:text-red-500 transition-colors">
              <Heart className="h-5 w-5" />
              <span>{post.likes}</span>
            </button>
            <button className="flex items-center space-x-1 text-gray-500 hover:text-blue-500 transition-colors">
              <MessageCircle className="h-5 w-5" />
              <span>{post.comments}</span>
            </button>
            <ShareButton 
              url={postUrl} 
              title={post.content}
              description={`Check out this post on Edoms Social: ${post.content}`}
            />
          </div>
        </div>
      </div>
    </div>
  );
}