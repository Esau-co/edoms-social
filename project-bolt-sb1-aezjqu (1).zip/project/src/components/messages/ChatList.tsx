import React from 'react';
import { formatDistanceToNow } from 'date-fns';

interface ChatPreview {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  timestamp: string;
  unread: number;
}

const chats: ChatPreview[] = [
  {
    id: '1',
    name: 'John Doe',
    avatar: 'https://api.dicebear.com/7.x/avatars/svg?seed=john',
    lastMessage: 'Hey, how are you?',
    timestamp: new Date().toISOString(),
    unread: 2,
  },
  // Add more mock data as needed
];

export function ChatList() {
  return (
    <div className="w-full max-w-md border-r border-gray-200 h-screen overflow-y-auto">
      <div className="p-4">
        <input
          type="text"
          placeholder="Search messages..."
          className="w-full px-4 py-2 rounded-full bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      <div className="divide-y divide-gray-200">
        {chats.map((chat) => (
          <div
            key={chat.id}
            className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
          >
            <div className="flex items-center space-x-3">
              <img
                src={chat.avatar}
                alt={chat.name}
                className="w-12 h-12 rounded-full"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{chat.name}</h3>
                  <span className="text-sm text-gray-500">
                    {formatDistanceToNow(new Date(chat.timestamp), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
              </div>
              {chat.unread > 0 && (
                <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                  {chat.unread}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}