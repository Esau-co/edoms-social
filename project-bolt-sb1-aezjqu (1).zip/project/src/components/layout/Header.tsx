import React from 'react';
import { Link } from 'react-router-dom';
import { Home, MessageCircle, Bell, User, Search } from 'lucide-react';
import { useAuthStore } from '../../store/auth';
import { Logo } from '../common/Logo';
import { WalletButton } from '../wallet/WalletButton';

export function Header() {
  const { user, isAuthenticated } = useAuthStore();
  const [showAuthModal, setShowAuthModal] = React.useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-50">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="hover:opacity-90 transition-opacity">
          <Logo />
        </Link>
        
        <div className="flex-1 max-w-xl px-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <nav className="flex items-center space-x-6">
          {isAuthenticated ? (
            <>
              <WalletButton />
              <Link to="/" className="text-gray-700 hover:text-blue-600">
                <Home className="h-6 w-6" />
              </Link>
              <Link to="/messages" className="text-gray-700 hover:text-blue-600">
                <MessageCircle className="h-6 w-6" />
              </Link>
              <Link to="/notifications" className="text-gray-700 hover:text-blue-600">
                <Bell className="h-6 w-6" />
              </Link>
              <Link to="/profile" className="flex items-center space-x-2">
                {user?.avatar ? (
                  <img src={user.avatar} alt={user.name} className="h-8 w-8 rounded-full" />
                ) : (
                  <User className="h-8 w-8 p-1 rounded-full bg-gray-200" />
                )}
              </Link>
            </>
          ) : (
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowAuthModal(true)}
                className="px-4 py-2 rounded-full bg-blue-600 text-white hover:bg-blue-700"
              >
                Login / Register
              </button>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
}