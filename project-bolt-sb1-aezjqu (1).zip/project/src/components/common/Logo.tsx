import React from 'react';

interface LogoProps {
  className?: string;
}

export function Logo({ className = "" }: LogoProps) {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className="relative w-10 h-10">
        <img 
          src="/edoms-social-logo.svg" 
          alt="Edoms Social"
          className="w-full h-full object-contain"
        />
      </div>
      <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
        Edoms Social
      </span>
    </div>
  );
}