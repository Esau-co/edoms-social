import React, { useState } from 'react';
import { Share2, Copy, Check, X } from 'lucide-react';
import {
  FacebookShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  TelegramShareButton,
  LinkedinShareButton,
  EmailShareButton,
  FacebookIcon,
  TwitterIcon,
  WhatsappIcon,
  TelegramIcon,
  LinkedinIcon,
  EmailIcon
} from 'react-share';

interface ShareButtonProps {
  url: string;
  title: string;
  description?: string;
}

export function ShareButton({ url, title, description = '' }: ShareButtonProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowMenu(!showMenu)}
        className="flex items-center space-x-2 text-gray-500 hover:text-blue-500 transition-colors"
        aria-label="Share"
      >
        <Share2 className="h-5 w-5" />
        <span>Share</span>
      </button>

      {showMenu && (
        <div className="absolute bottom-full left-0 mb-2 bg-white rounded-lg shadow-xl p-4 min-w-[280px] z-50">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-semibold text-gray-700">Share this post</h3>
            <button
              onClick={() => setShowMenu(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            <FacebookShareButton url={url} quote={title} className="w-full">
              <div className="flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <FacebookIcon size={32} round />
                <span className="text-xs mt-1">Facebook</span>
              </div>
            </FacebookShareButton>

            <TwitterShareButton url={url} title={title} className="w-full">
              <div className="flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <TwitterIcon size={32} round />
                <span className="text-xs mt-1">Twitter</span>
              </div>
            </TwitterShareButton>

            <WhatsappShareButton url={url} title={title} className="w-full">
              <div className="flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <WhatsappIcon size={32} round />
                <span className="text-xs mt-1">WhatsApp</span>
              </div>
            </WhatsappShareButton>

            <TelegramShareButton url={url} title={title} className="w-full">
              <div className="flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <TelegramIcon size={32} round />
                <span className="text-xs mt-1">Telegram</span>
              </div>
            </TelegramShareButton>

            <LinkedinShareButton url={url} title={title} summary={description} className="w-full">
              <div className="flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <LinkedinIcon size={32} round />
                <span className="text-xs mt-1">LinkedIn</span>
              </div>
            </LinkedinShareButton>

            <EmailShareButton url={url} subject={title} body={description} className="w-full">
              <div className="flex flex-col items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <EmailIcon size={32} round />
                <span className="text-xs mt-1">Email</span>
              </div>
            </EmailShareButton>
          </div>

          <div className="relative">
            <button
              onClick={handleCopyLink}
              className="w-full flex items-center justify-center space-x-2 p-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-green-500">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  <span>Copy link</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}